package de.kaanunsal.ilservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IlServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
